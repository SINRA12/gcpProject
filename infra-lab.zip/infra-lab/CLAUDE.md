# CLAUDE.md

Context for Claude Code working in this repository.

## What this is

A personal learning lab that rebuilds a typical enterprise request path on Google Cloud,
mirroring a company setup ("GK" test environment) the owner works with:

User → Cloudflare (optional) → Google Classic Application Load Balancer + Cloud Armor
→ HAProxy (regional managed instance group, private IPs) → ingress-nginx in one of two
GKE clusters (`flight`, `payment`, via internal load balancers on reserved IPs)
→ demo `traefik/whoami` services in per-service namespaces (`flight-cart-be-ns`, ...).

The owner is learning infrastructure concepts. When making changes, explain the
"why" in plain language, not only the code.

## Layout

| Path | Purpose |
| --- | --- |
| `1-platform/` | VPC, subnet, Cloud NAT, firewall, 2 GKE clusters, reserved IPs |
| `2-k8s/` | ingress-nginx + demo apps per cluster (`modules/cluster-apps`) |
| `3-cloudflare/` | Optional: DNS record + Origin CA cert |
| `4-edge/` | HAProxy MIG, health check, LB chain, Cloud Armor, HTTPS |
| `bootstrap/setup-gcp.sh` | One-time: state bucket, CI service account, Workload Identity Federation |
| `lab.sh` | Entry point: `up`, `down`, `plan`, `check`, `status`, `test` |
| `scripts/ci-write-tfvars.sh` | Builds `lab.tfvars` from env vars in CI |
| `.github/workflows/` | `pr.yml` (check + plan), `lab.yml` (manual up/down, nightly down) |

Stages are separate Terraform roots with state in GCS under `infra-lab/<stage>`.
Later stages read earlier ones through `terraform_remote_state`. Changing or removing
an output in one stage means updating every stage that reads it.

## Commands

- `./lab.sh check` — fmt + validate, no cloud access. Run before every commit.
- `./lab.sh plan` — read-only against the real project.
- `./lab.sh up` / `./lab.sh down` — create / destroy everything.

## Rules

- **Never run `./lab.sh up`, `./lab.sh down`, `terraform apply` or `terraform destroy`
  without the owner explicitly asking in this session.** They cost money or delete things.
- Never commit `*.tfstate`, `lab.tfvars`, `.terraform/`, keys or tokens (see `.gitignore`).
  Secrets come from environment variables or GitHub secrets only.
- Keep `terraform fmt` clean; CI fails otherwise.
- Make changes on a branch and open a pull request; `pr.yml` runs checks and a plan.
- Keep provider versions pinned in each stage's `required_providers`; bump deliberately.
- Keep every resource destroyable by `./lab.sh down` (no `prevent_destroy`, no deletion protection).

## Known state

- The code was written without a live `terraform validate`/apply; the first real run
  may need small fixes (provider or chart versions).
- ingress-nginx was retired upstream in March 2026; it is kept here only to mirror the
  real setup. Migrating to a Gateway API implementation is a planned exercise.
- Cloudflare zone settings (SSL Full (strict), Always Use HTTPS) are set manually in
  the dashboard, not by Terraform.

## Ideas backlog

- Migrate ingress-nginx to Gateway API (e.g. Envoy Gateway) in one cluster, compare.
- Add Prometheus + Grafana (kube-prometheus-stack) with a pod dashboard.
- Cloud Armor rate limiting keyed on `CF-Connecting-IP`.
- Manage Cloudflare zone settings and WAF rules in Terraform.
- Post the plan as a pull request comment instead of the job summary.
- Tighten the CI service account's IAM roles.

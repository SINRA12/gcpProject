# Infra lab as code

A learning lab that rebuilds an enterprise request path on Google Cloud with Terraform:

```
User → Cloudflare (optional) → Google Classic Application Load Balancer + Cloud Armor
     → HAProxy (managed instance group) → ingress-nginx (flight / payment GKE clusters)
     → demo services in their own namespaces
```

Build it at the start of a session, destroy it at the end, and pay only for the hours
it exists.

## Stages

| Stage | Creates | Reads from |
| --- | --- | --- |
| `1-platform` | VPC, subnet, Cloud NAT, firewall rules, `flight` and `payment` GKE clusters, reserved internal ingress IPs, global load balancer IP | — |
| `2-k8s` | ingress-nginx (2 replicas, internal LB on the reserved IP) and demo `whoami` services, in both clusters | 1 |
| `3-cloudflare` (optional) | Proxied DNS record to the load balancer IP, Cloudflare Origin CA certificate | 1 |
| `4-edge` | HAProxy instance template + regional MIG, health check, load balancer chain, Cloud Armor, HTTPS when Cloudflare is on | 1, 3 |

Each stage is its own Terraform root, because the Kubernetes and Helm providers need
the clusters to exist before they can be configured. State lives in a GCS bucket
(`infra-lab/<stage>`), with locking and versioning, so local runs and GitHub Actions
share it safely.

## Getting started

1. **Push to GitHub and set up CI**: follow [docs/github-setup.md](docs/github-setup.md).
   It covers the one-time `bootstrap/setup-gcp.sh` (state bucket + keyless GitHub
   authentication) and the repository variables.
2. **Run locally** (Cloud Shell has `terraform` preinstalled):

```bash
cp lab.tfvars.example lab.tfvars     # fill in project_id, state_bucket, my_ips
./lab.sh check     # fmt + validate, no cloud access
./lab.sh up        # ~15-20 min
./lab.sh test
./lab.sh down      # always, when you finish
```

Outside Cloud Shell, run `gcloud auth application-default login` first.

To use kubectl against the clusters:

```bash
gcloud container clusters get-credentials flight-cluster --zone <zone>
kubectl get pods -A
```

## Enabling Cloudflare

One-time, in the Cloudflare dashboard (persists for free between sessions):

1. Add your domain (Free plan) and switch the registrar's nameservers to Cloudflare's.
2. **SSL/TLS → Overview**: **Full (strict)**.
3. **SSL/TLS → Edge Certificates**: **Always Use HTTPS**, minimum TLS 1.2.
4. Create an API token with **Zone → DNS → Edit** and **Zone → SSL and Certificates → Edit**.

Then set `enable_cloudflare = true`, `domain`, `cloudflare_zone_id` and `my_ips = []`
in `lab.tfvars` (or the matching GitHub variables), export `CLOUDFLARE_API_TOKEN`
(or add it as a GitHub secret), and run `up`. The DNS record follows the load
balancer IP automatically on every rebuild.

## Cost

GKE nodes and cluster fees, VMs, load balancer forwarding rules and NAT all bill by
the hour. `./lab.sh down` removes everything; the `Lab` workflow also runs `down`
nightly as a safety net. Keep a budget alert on the project. The state bucket stays
and costs close to nothing.

## Troubleshooting

- **Stage 1 destroy fails on the internal IPs or VPC:** GKE was still deleting the
  internal load balancers. Wait a minute and run `./lab.sh down` again.
- **502 right after `up`:** HAProxy VMs are still installing (about 2 minutes). Check
  `gcloud compute backend-services get-health haproxy-backend --global`.
- **ingress-nginx chart version not found:** `helm search repo ingress-nginx/ingress-nginx --versions`,
  then set `ingress_chart_version` in `2-k8s/modules/cluster-apps/variables.tf`.
- **State lock error:** another run (local or CI) is in progress. Wait for it; only use
  `terraform force-unlock` if you're sure nothing is running.
- **ingress-nginx is retired upstream** (March 2026). It's kept to mirror the real
  setup; migrating to Gateway API is a good follow-up exercise.

The code was written without a live validate/apply, so the first run may need small
version fixes. See `CLAUDE.md` for working on this repo with Claude Code.
